# Notes

- `listener.js` is the main script. `content.js` simply organises the insertion of `Autolinker.js` and `listener.js` in the DOM.
- `Autolinker.js` is (obviously) an external autolinking library. 
- Press an F2 button once, and this extension should work perfectly.
